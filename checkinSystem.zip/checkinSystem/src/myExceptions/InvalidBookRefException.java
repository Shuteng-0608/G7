package myExceptions;

public class InvalidBookRefException extends Exception {
	public InvalidBookRefException(String message) {
        super(message);
    }
}
