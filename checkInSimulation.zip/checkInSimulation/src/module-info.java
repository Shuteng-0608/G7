/**
 * 
 */
/**
 * 
 */
module checkInSimulation {
	requires java.desktop;
}