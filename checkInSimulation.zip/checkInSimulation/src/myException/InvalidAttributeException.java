package myException;

public class InvalidAttributeException extends Exception{
	public InvalidAttributeException(String message) {
        super(message);
    }
}
